package com.example.image_classifier

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
