import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tflite/tflite.dart';
import 'dart:io';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  File? _image;
  List? _predictions;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadModel();
  }

  Future<void> _loadModel() async {
    await Tflite.loadModel(
      model: "assets/mobilenet_v1_1.0_224.tflite",
      labels: "assets/labels.txt",
    );
  }

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    if (pickedFile == null) return;

    setState(() {
      _image = File(pickedFile.path);
      _isLoading = true;
    });

    _classifyImage(File(pickedFile.path));
  }

  Future<void> _classifyImage(File image) async {
    var predictions = await Tflite.runModelOnImage(
      path: image.path,
      numResults: 3, // Get top 3 predictions
      threshold: 0.2, // Confidence threshold
      imageMean: 127.5,
      imageStd: 127.5,
    );

    setState(() {
      _predictions = predictions;
      _isLoading = false;
    });
  }

  @override
  void dispose() {
    Tflite.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text("Flutter ML Image Classifier")),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _image == null
                  ? Text("No image selected")
                  : Image.file(_image!, height: 200),
              SizedBox(height: 20),
              _isLoading
                  ? CircularProgressIndicator()
                  : _predictions != null
                  ? Column(
                    children:
                        _predictions!.map((result) {
                          return Text(
                            "${result["label"]} - ${(result["confidence"] * 100).toStringAsFixed(2)}%",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          );
                        }).toList(),
                  )
                  : Container(),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _pickImage,
                child: Text("Pick an Image"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
